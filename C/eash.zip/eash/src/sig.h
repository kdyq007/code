#define CLICK_RATE 5

void stop_timer(void);
void init_timer(void);
void reset_timer(void);
void init_signal(void);
void sighup_restart(void);
int duration(void);
