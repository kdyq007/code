	int sql_init_db(const char *);
	int sql_audits(const char *file);
